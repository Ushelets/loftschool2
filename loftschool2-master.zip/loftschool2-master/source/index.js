import createMenu from './menu';
var menu = createMenu([
    'Главная!!','Обо мне','Портфолио'
],'menu');
document.body.appendChild(menu);
